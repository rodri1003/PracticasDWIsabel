const estudiante = {
    nombre: "Isabel",
    edad: 24,
    direccion: {
      calle: "Calle Principal Barrio Arriba",
      ciudad: "Guatajiagua"
    },
    materias: ["Matemáticas", "Programación", "Física"]
  };
  
  console.log(estudiante.direccion.ciudad);
  console.log(estudiante.materias[1]);
  