const persona = {
    nombre: "Isabel",
    edad: 24,          
    profesion: "Ingeniera" 
  };
  
  console.log(persona.nombre);
  console.log(persona.edad);
  console.log(persona.profesion);
  